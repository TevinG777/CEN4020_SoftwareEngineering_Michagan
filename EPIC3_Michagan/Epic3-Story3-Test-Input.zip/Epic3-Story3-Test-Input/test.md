test 1 - Look for existing user
test 2 - look for non-existing user
test 3 - look for blank user