Test 1: Testing the search of one user
Test 2: Testing the serach with invalid user
Test 3: Testing display all profile fields
Test 4: Searching for blank user
Test 5: Account that doesn't exist