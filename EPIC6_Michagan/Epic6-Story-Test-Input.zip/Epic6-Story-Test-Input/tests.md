1) Testing Job Posting
2) Testing to see if Not privoded shows up for missign field
3) Testing NONE for salary field
4) Testing for non-integer characters in salary field
5) Testing none for each field
6) Testing delimited symbols in fields
7) Testing character limit
