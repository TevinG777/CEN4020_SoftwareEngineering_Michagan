test 1 - Create → auto-login → go edit profile, then back
test 2 - Log in and see profile
test 3 - Profile: invalid grad year formats then valid
test 4 - Try to add 4 experiences
test 5 - 3 Education entries; attempt a 4th.