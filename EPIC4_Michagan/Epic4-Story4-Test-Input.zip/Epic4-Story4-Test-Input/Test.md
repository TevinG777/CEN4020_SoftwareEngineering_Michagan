Test1: Basic connection request
Test2: Basic connection request to another user
Test3: Connection request to self
Test4: Invalid characters in connection request