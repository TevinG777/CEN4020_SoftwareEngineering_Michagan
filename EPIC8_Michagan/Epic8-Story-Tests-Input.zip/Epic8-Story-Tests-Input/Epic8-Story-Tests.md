1) test1.txt - Viewing existing applications for a user who already has at least one application.
2) test2.txt - Submitting a new job application and verifying it is recorded/persisted.
3) test3.txt - Blocking duplicate applications for the same user and job without changing data.
4) test4.txt - Showing the correct message when a user has no applications.
5) test5.txt - Sending a message to a connected user.
6) test6.txt - Preventing messaging to someone outside your network. 
